package org.example.helloservletproject.service;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.example.helloservletproject.dao.UserDAO;
import org.example.helloservletproject.mybatis.MyBatisSessionFactory;
import org.example.helloservletproject.vo.UserVO;

public class LoginServiceOracleImpl implements LoginService {

    @Override
    public UserVO userLogin(String id, String password) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserDAO userDAO = new UserDAO(sqlSession);
        UserVO result = userDAO.login(id, password);
        return result;
    }
}
