package org.example.helloservletproject.dao;

import org.apache.ibatis.session.SqlSession;
import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.BookVO;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BoardDAO {
    private SqlSession sqlSession;

    public BoardDAO() {

    }

    public BoardDAO(SqlSession sqlSession) {this.sqlSession = sqlSession;}


    public Collection<? extends BoardVO> selectAllBoard() {
        List<BoardVO> boardVOList = null;

        try {
            boardVOList = sqlSession.selectList("example.MyBoard.selectAllBoard");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }

        return boardVOList;
    }

    public BoardVO getBoardDetail(int id) {

        BoardVO boardVO = null;
        try {
            boardVO = sqlSession.selectOne("example.MyBoard.getBoardDetail", id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }

        return boardVO;
    }


    public int insert(BoardVO boardVO) {
        int result = 0;

        try {
            result = sqlSession.insert("example.MyBoard.insert", boardVO);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
    //            sqlSession.close();
        }
        return result;
    }

    public int delete(int id) {
        int result = 0;

        try {
            result = sqlSession.delete("example.MyBoard.delete", id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }

        return result;
    }
}
