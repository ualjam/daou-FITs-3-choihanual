package org.example.helloservletproject;

import org.example.helloservletproject.service.BoardService;
import org.example.helloservletproject.service.BoardServiceOracleImpl;
import org.example.helloservletproject.service.LoginService;
import org.example.helloservletproject.service.LoginServiceOracleImpl;
import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.BookVO;
import org.example.helloservletproject.vo.UserVO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


@WebServlet(value = "/myServlet/login")
public class login extends HttpServlet {

    public login() {}

    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        super.doGet(req, resp);
        BoardService boardService = new BoardServiceOracleImpl();
        List<BoardVO> boardVOList = boardService.getBoardList();
        RequestDispatcher rd = req.getRequestDispatcher("/welcome.jsp");
        req.setAttribute("board", boardVOList);
        rd.forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 클라이언트의 요청이 GET 방식일 때 호출
        // 입력받고
        // Query String으로 전달되는 데이터는 무조건 문자열
        // 입려긍ㄹ 받을 때 만약 한글과 같은 유니코드가 포함되어 있다면
        req.setCharacterEncoding("utf-8");

        String id = req.getParameter("id");
        String password = req.getParameter("password");

        LoginService service = new LoginServiceOracleImpl();
        UserVO result = service.userLogin(id, password);

        BoardService boardService = new BoardServiceOracleImpl();
        List<BoardVO> boardVOList = boardService.getBoardList();

        System.out.println(boardVOList);
        for (BoardVO board : boardVOList) {
            System.out.println("Title: " + board.getTitle());
        }

        // 로직처리하고
        // 직접 로직처리하지 않아요!
        // 서비스 객체가 나와야 해요!
        // 서비스 객체에게 로직처리를 시켜요!
        // 그 결과를 가져다가 화면에 출력!
        // MVC 패턴의 관점에서 바라보면 우리의 servlet은 controller의
        // 역할을 수행!

        // 출력처리하면 돼요!
        // 서블릿이 클라이언트에게 처리된 결과를 돌려주려면
        // 1. 데이터 전달 통로를 열어서 결과 데이터를 전달해야 하는데
        //    이 통로를 통해서 전달되는 데이터의 형태가 어떤 형태인지를 먼저 지정해야 해요
        resp.setContentType("text/html; charset=utf-8");

        if (result != null) {
            // 로그인 성공: "도서 검색" 버튼 추가
            // WAS에게 session 저장공간을 하나 주세요! 라고 요청
            HttpSession session = req.getSession();
            // req.getSession(false);
            // 기존에 할당된 session객체가 이미 존재하면 가져다 주시구요!
            // 없으면 새로 만들지 말고 null을 리턴하세요!

            session.setAttribute("member", result);

            // setAttribute를 이용해서 값을 저장할 수 있어요!
            // getAttribute로 값을 다시 꺼내올 수 있어요!

            // JSP 이용해서 View 처리
            RequestDispatcher rd = req.getRequestDispatcher("/welcome.jsp");
            req.setAttribute("hoho", result);
            req.setAttribute("board", boardVOList);
            rd.forward(req, resp);

            // invalidate() : 세션을 무효화 시키는거예요!

//            out.println("<p>환영합니다, " + result.getMember_name() + "님!</p>");
//            out.println("<form action='http://localhost:8080/HelloServletProject_war_exploded/input.html' method='get'>");
//            out.println("<button type='submit'>도서 검색</button>");
//            out.println("</form>");
        } else {
            // 로그인 실패
            resp.sendRedirect("/loginError.html");
//            out.println("<p>그런 사람 없습니다</p>");
        }

//        out.println("</body>");
//        out.println("</html>");
//        out.flush();
//        out.close();
    }
}
