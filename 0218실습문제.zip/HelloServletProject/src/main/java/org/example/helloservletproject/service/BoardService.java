package org.example.helloservletproject.service;

import org.example.helloservletproject.vo.BoardVO;

import java.util.List;

public interface BoardService {
    List<BoardVO> getBoardList();
    boolean createBoard(BoardVO board);
    boolean deleteBoard(int board_id);
    BoardVO getBoardDetail(int board_id);
}
