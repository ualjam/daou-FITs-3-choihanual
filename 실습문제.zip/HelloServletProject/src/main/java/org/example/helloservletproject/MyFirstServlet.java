package org.example.helloservletproject;

import org.example.helloservletproject.service.BookSearchService;
import org.example.helloservletproject.service.BookSearchServiceOracleImpl;
import org.example.helloservletproject.vo.BookVO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(value = "/myServlet")
public class MyFirstServlet extends HttpServlet {

    public MyFirstServlet() {
        System.out.println("생성자 호출");
    }

    @Override
    public void init() throws ServletException {
        super.init();
        // 초기화 코드가 들어와요!
        System.out.println("init가 호출되었어요!");
    }

//    @Override
//    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        super.service(req, resp);
//        // 일반적으로 overriding하지 않아요!
//
//    }


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 클라이언트의 요청이 GET 방식일 때 호출
        // 입력받고
        // Query String으로 전달되는 데이터는 무조건 문자열
        String id = req.getParameter("bisbn");

        BookSearchService service = new BookSearchServiceOracleImpl();
        BookVO result = service.getBookDetail(id);

        System.out.println(result);
        // 로직처리하고
        // 출력처리하면 돼요!
        // 서블릿이 클라이언트에게 처리된 결과를 돌려주려면
        // 1. 데이터 전달 통로를 열어서 결과 데이터를 전달해야 하는데
        //    이 통로를 통해서 전달되는 데이터의 형태가 어떤 형태인지를 먼저 지정해야 해요
        resp.setContentType("text/html;charset=utf-8");

        // 2. 결과를 돌려주기 위한 데이터 통로를 하나 열어야 해요!
        //    이 데이터 통로는 일반적으로 PrintWriter를 이용
        PrintWriter out = resp.getWriter();

        // 3. 이렇게 열린 통로로 데이터를 전송하면 돼요!
        out.println("<html>");
        out.println("<head><meta charset='UTF-8'><title>도서 상세 정보</title></head>");
        out.println("<body>");
        out.println("<h2>도서 상세 정보</h2>");

        if (result != null) {
            out.println("<p><strong>제목:</strong> " + result.getBtitle() + "</p>");
            out.println("<p><strong>가격:</strong> " + result.getBprice() + "원</p>");
            out.println("<p><strong>저자:</strong> " + result.getBauthor() + "</p>");
            out.println("<p><strong>출판사:</strong> " + result.getBpublisher() + "</p>");
            out.println("<p><strong>번역자:</strong> " + result.getBtranslator() + "</p>");
        } else {
            out.println("<p>해당 도서를 찾을 수 없습니다.</p>");
        }

        out.println("<br><a href='/myServlet'>도서 목록으로 돌아가기</a>");
        out.println("</body>");
        out.println("</html>");

        out.flush();
        out.close();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 클라이언트의 요청이 GET 방식일 때 호출
        // 입력받고
        // Query String으로 전달되는 데이터는 무조건 문자열
        // 입려긍ㄹ 받을 때 만약 한글과 같은 유니코드가 포함되어 있다면
        req.setCharacterEncoding("utf-8");

        String keyword = req.getParameter("keyword");
        String price = req.getParameter("price");

        BookSearchService service = new BookSearchServiceOracleImpl();
        List<BookVO> result = service.searchBookByTitleKeyword(keyword, Integer.parseInt(price));
        for (BookVO book : result) {
            System.out.println("Title: " + book.getBtitle() + ", Price: " + book.getBprice() + ", Author: " + book.getBauthor());
        }

        // 로직처리하고
        // 직접 로직처리하지 않아요!
        // 서비스 객체가 나와야 해요!
        // 서비스 객체에게 로직처리를 시켜요!
        // 그 결과를 가져다가 화면에 출력!
        // MVC 패턴의 관점에서 바라보면 우리의 servlet은 controller의
        // 역할을 수행!

        // 출력처리하면 돼요!
        // 서블릿이 클라이언트에게 처리된 결과를 돌려주려면
        // 1. 데이터 전달 통로를 열어서 결과 데이터를 전달해야 하는데
        //    이 통로를 통해서 전달되는 데이터의 형태가 어떤 형태인지를 먼저 지정해야 해요
        resp.setContentType("text/html; charset=utf-8");

        // 2. 결과를 돌려주기 위한 데이터 통로를 하나 열어야 해요!
        //    이 데이터 통로는 일반적으로 PrintWriter를 이용
        PrintWriter out = resp.getWriter();

        // 3. 이렇게 열린 통로로 데이터를 전송하면 돼요!
        out.println("<html>");
        out.println("<head><meta charset='UTF-8'><title>도서 검색 결과</title></head>");
        out.println("<body>");
        out.println("<h2>도서 검색 결과</h2>");
        out.println("<table border='1' style='border-collapse:collapse; width: 60%;'>");
        out.println("<tr><th>제목</th><th>가격</th><th>저자</th></tr>");

// 검색 결과를 테이블에 추가 (책 제목을 클릭하면 상세 페이지로 이동)
        for (BookVO book : result) {
            out.println("<tr>");
            out.println("<td><a href='myServlet?bisbn=" + book.getBisbn() + "'>" + book.getBtitle() + "</a></td>");
            out.println("<td>" + book.getBprice() + "원</td>");
            out.println("<td>" + book.getBauthor() + "</td>");
            out.println("</tr>");
        }

        out.println("</table>");
        out.println("</body>");
        out.println("</html>");
        out.flush();
        out.close();

    }

    @Override
    public void destroy() {
        super.destroy();
        // resource 해제 코드
        System.out.println("destroy가 호출되었어요!");
    }
}
