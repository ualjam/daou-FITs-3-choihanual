package org.example.helloservletproject.dao;

import org.apache.ibatis.session.SqlSession;
import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.LikeVO;

import java.util.HashMap;
import java.util.Map;

public class LikeDAO {
    private SqlSession sqlSession;

    public LikeDAO() {

    }

    public LikeDAO(SqlSession sqlSession) {this.sqlSession = sqlSession;}

    public LikeVO isUserLiked(int boardId, String userId) {

        LikeVO likeVO = null;

        Map<String, Object> params = new HashMap<>();
        params.put("boardId", boardId);
        params.put("userId", userId);
        try {
            likeVO = sqlSession.selectOne("example.MyLike.isUserLiked", params);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }

        return likeVO;
    }

    public int insert(int boardId, String userId) {
        int result = 0;

        Map<String, Object> params = new HashMap<>();
        params.put("boardId", boardId);
        params.put("userId", userId);

        try {
            result = sqlSession.insert("example.MyLike.insert", params);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //            sqlSession.close();
        }
        return result;
    }

    public int delete(int boardId, String userId) {
        int result = 0;

        Map<String, Object> params = new HashMap<>();
        params.put("boardId", boardId);
        params.put("userId", userId);

        try {
            result = sqlSession.delete("example.MyLike.delete", params);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }

        return result;
    }

    public int addLikeCount(int boardId) {
        int result = 0;

        try {
            result = sqlSession.update("example.MyLike.addLikeCount", boardId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }

        return result;
    }

    public int minusLikeCount(int boardId) {
        int result = 0;

        try {
            result = sqlSession.update("example.MyLike.minusLikeCount", boardId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }

        return result;
    }

    public int getLikeCount(int id) {

        int likeCount = 0;
        try {
            likeCount = sqlSession.selectOne("example.MyLike.getLikeCount", id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }

        System.out.println(likeCount);

        return likeCount;
    }
}
