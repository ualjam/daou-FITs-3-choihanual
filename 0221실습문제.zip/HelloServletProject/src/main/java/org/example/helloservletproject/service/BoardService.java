package org.example.helloservletproject.service;

import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.BookVO;

import java.util.List;

public interface BoardService {
    List<BoardVO> getBoardList();
    List<BoardVO> searchBoards(String keyword);
    boolean createBoard(BoardVO board);
    boolean updateBoard(BoardVO board);
    boolean updateViewCount(int boardId);
    boolean deleteBoard(int board_id);
    BoardVO getBoardDetail(int board_id);
}
