package org.example.helloservletproject.service;

import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.CommentVO;

import java.util.List;

public interface CommentService {
    List<CommentVO> getCommentList(int boardId);
    int addComment(CommentVO comment);
    boolean deleteComment(int commentId);
    boolean addCommentCount(int boardId);
    boolean minusCommentCount(int boardId);
    int getCommentCount(int boardId);
}
