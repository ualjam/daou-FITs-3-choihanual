package org.example.helloservletproject;

import org.example.helloservletproject.service.BoardService;
import org.example.helloservletproject.service.BoardServiceOracleImpl;
import org.example.helloservletproject.service.LoginService;
import org.example.helloservletproject.service.LoginServiceOracleImpl;
import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.BookVO;
import org.example.helloservletproject.vo.UserVO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


@WebServlet(value = "/myServlet/login")
public class login extends HttpServlet {

    public login() {}

    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        super.doGet(req, resp);
        BoardService boardService = new BoardServiceOracleImpl();
        List<BoardVO> boardVOList = boardService.getBoardList();
        RequestDispatcher rd = req.getRequestDispatcher("/boardList.jsp");
        req.setAttribute("board", boardVOList);
        rd.forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 클라이언트의 요청이 GET 방식일 때 호출
        // 입력받고
        // Query String으로 전달되는 데이터는 무조건 문자열
        // 입려긍ㄹ 받을 때 만약 한글과 같은 유니코드가 포함되어 있다면
        req.setCharacterEncoding("utf-8");

        String id = req.getParameter("id");
        String password = req.getParameter("password");

        LoginService service = new LoginServiceOracleImpl();
        UserVO result = service.userLogin(id, password);

        resp.setContentType("text/html; charset=utf-8");

        if (result != null) {
            // 세션에 사용자 정보 저장
            HttpSession session = req.getSession();
            session.setAttribute("member", result);

            // 게시판 데이터를 불러오지 않고, 로그인 성공 후 welcome 페이지로 이동
            RequestDispatcher rd = req.getRequestDispatcher("/welcome.jsp");
            rd.forward(req, resp);
        } else {
            // 로그인 실패 시 로그인 오류 페이지로 이동
            resp.sendRedirect("/loginError.html");
        }

//        out.println("</body>");
//        out.println("</html>");
//        out.flush();
//        out.close();
    }
}
