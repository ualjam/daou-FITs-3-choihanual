package org.example.helloservletproject.dao;

import java.util.Collection;
import org.example.helloservletproject.vo.BookVO;
import org.apache.ibatis.session.SqlSession;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

// 이전에는 transaction 처리를 위해 Connection 전달
// 이번에는 SqlSessionFactory 전달
public class BookDAO {
    private SqlSession sqlSession;

    public BookDAO() {
    }

    public BookDAO(SqlSession sqlSession) {
        this.sqlSession = sqlSession;
    }

    public Collection<? extends BookVO> selectByTitleKeyword(String keyword, Integer price) {
        List<BookVO> bookVOList = null;

        Map<String, Object> params = new HashMap<>();
        params.put("keyword", "%" + keyword + "%");
        params.put("price", price);

        try {
            bookVOList = sqlSession.selectList("example.MyBook.selectByTitleKeyword", params);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }

        return bookVOList;
    }

    public BookVO getBookDetail(String id) {

        BookVO bookVO = null;
        try {
            bookVO = sqlSession.selectOne("example.MyBook.getBookDetail", id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }

        return bookVO;
    }



//    public int insert(BookVO bookVO) {
//        int result = 0;
//
//        try {
//            result = sqlSession.insert("example.MyBook.insert", bookVO);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
////            sqlSession.close();
//        }
//        return result;
//    }
//
//    public int update(BookVO bookVO) {
//        int result = 0;
//
//        try {
//            result = sqlSession.update("example.MyBook.update", bookVO);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//        }
//
//        return result;
//    }
//
//    public int delete(String isbn) {
//        int result = 0;
//
//        try {
//            result = sqlSession.delete("example.MyBook.delete", isbn);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//
//        }
//
//        return result;
//    }
}
