package org.example.helloservletproject;

import org.example.helloservletproject.service.BoardService;
import org.example.helloservletproject.service.BoardServiceOracleImpl;
import org.example.helloservletproject.vo.BoardVO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/myServlet/board/search")
public class BoardSearchServlet extends HttpServlet {
    private BoardService boardService = new BoardServiceOracleImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        // 검색어 파라미터 가져오기
        String searchKeyword = req.getParameter("searchKeyword");

        // 검색어가 비어 있거나 null이면 전체 리스트 반환
        List<BoardVO> boardList;
        if (searchKeyword == null || searchKeyword.trim().isEmpty()) {
            boardList = boardService.getBoardList(); // 전체 게시글 반환
        } else {
            boardList = boardService.searchBoards(searchKeyword); // 검색된 게시글 반환
        }

        System.out.println(boardList);


        RequestDispatcher rd = req.getRequestDispatcher("/boardList.jsp");
        req.setAttribute("board", boardList);
        rd.forward(req, resp);
    }
}
