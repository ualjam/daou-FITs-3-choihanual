package org.example.helloservletproject.service;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.example.helloservletproject.dao.BoardDAO;
import org.example.helloservletproject.dao.LikeDAO;
import org.example.helloservletproject.mybatis.MyBatisSessionFactory;
import org.example.helloservletproject.vo.LikeVO;

public class LikeServiceOracleImpl implements LikeService{
    @Override
    public LikeVO isUserLiked(int boardId, String userId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        LikeDAO likeDAO = new LikeDAO(sqlSession);

        LikeVO result = likeDAO.isUserLiked(boardId, userId);

        return result;
    }

    @Override
    public boolean removeLike(int boardId, String userId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        LikeDAO likeDAO = new LikeDAO(sqlSession);

        boolean result = likeDAO.delete(boardId, userId) == 1;

        System.out.println(result);

        if (result) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return result;
    }

    @Override
    public boolean addLike(int boardId, String userId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        LikeDAO likeDAO = new LikeDAO(sqlSession);


        boolean result = likeDAO.insert(boardId, userId) == 1;

        if (result) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return result;
    }

    @Override
    public boolean addLikeCount(int boardId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        LikeDAO likeDAO = new LikeDAO(sqlSession);

        boolean result = likeDAO.addLikeCount(boardId) == 1;
        if (result) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return result;
    }

    @Override
    public boolean minusLikeCount(int boardId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        LikeDAO likeDAO = new LikeDAO(sqlSession);
        boolean result = likeDAO.minusLikeCount(boardId) == 1;
        if (result) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return result;
    }

    @Override
    public int getLikeCount(int boardId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        LikeDAO likeDAO = new LikeDAO(sqlSession);
        int result = likeDAO.getLikeCount(boardId);

        return result;
    }
}
