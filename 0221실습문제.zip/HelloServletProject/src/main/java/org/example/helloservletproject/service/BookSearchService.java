package org.example.helloservletproject.service;

import org.example.helloservletproject.vo.BookVO;

import java.util.List;

public interface BookSearchService {
    List<BookVO> searchBookByTitleKeyword(String keyword, Integer price);
    BookVO getBookDetail(String id);
//    boolean createBook(BookVO book);
//    boolean updateBook(BookVO book);
//    boolean deleteBook(String isbn);
}
