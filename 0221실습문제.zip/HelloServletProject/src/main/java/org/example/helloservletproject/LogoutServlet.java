package org.example.helloservletproject;

import org.example.helloservletproject.service.BoardService;
import org.example.helloservletproject.service.BoardServiceOracleImpl;
import org.example.helloservletproject.service.LoginService;
import org.example.helloservletproject.service.LoginServiceOracleImpl;
import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.BookVO;
import org.example.helloservletproject.vo.UserVO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(value = "/myServlet/logout")
public class LogoutServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);

        if (session != null) {
            session.invalidate();  // 세션 무효화 (로그아웃)
        }

        resp.sendRedirect(req.getContextPath() + "/login.html");  // 로그인 페이지로 리디렉트
    }
}
