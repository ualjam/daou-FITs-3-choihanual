package org.example.helloservletproject.service;

import org.example.helloservletproject.vo.UserVO;

public interface LoginService {
    UserVO userLogin(String id, String password);
}
