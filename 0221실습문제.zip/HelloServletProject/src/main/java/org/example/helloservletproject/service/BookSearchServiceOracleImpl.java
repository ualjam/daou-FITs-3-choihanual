package org.example.helloservletproject.service;

import org.example.helloservletproject.dao.BookDAO;
import org.example.helloservletproject.mybatis.MyBatisSessionFactory;
import org.example.helloservletproject.vo.BookVO;
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.ArrayList;
import java.util.List;

public class BookSearchServiceOracleImpl implements BookSearchService {
    @Override
    public List<BookVO> searchBookByTitleKeyword(String keyword, Integer price) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        System.out.println(keyword);
        System.out.println(price);
        BookDAO bookDAO = new BookDAO(sqlSession);
//        List<BookVO> bookVOList = FXCollections.observableArrayList();
        List<BookVO> bookVOList = new ArrayList<>();
        bookVOList.addAll(bookDAO.selectByTitleKeyword(keyword, price));
        return bookVOList;
    }

    @Override
    public BookVO getBookDetail(String id) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookDAO bookDAO = new BookDAO(sqlSession);
        BookVO result = bookDAO.getBookDetail(id);
        return result;
    }

//    @Override
//    public boolean createBook(BookVO book) {
//        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
//        SqlSession sqlSession = sqlSessionFactory.openSession();
//        BookDAO bookDAO = new BookDAO(sqlSession);
//        boolean result = bookDAO.insert(book) == 1;
//        if (result) {
//            sqlSession.commit();
//            sqlSession.close();
//        } else {
//            sqlSession.rollback();
//            sqlSession.close();
//        }
//        return result;
//    }
//
//    @Override
//    public boolean updateBook(BookVO book) {
//        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
//        SqlSession sqlSession = sqlSessionFactory.openSession();
//        BookDAO bookDAO = new BookDAO(sqlSession);
//        boolean result = bookDAO.update(book) == 1;
//        if (result) {
//            sqlSession.commit();
//            sqlSession.close();
//        } else {
//            sqlSession.rollback();
//            sqlSession.close();
//        }
//        return result;
//    }
//
//    @Override
//    public boolean deleteBook(String isbn) {
//        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
//        SqlSession sqlSession = sqlSessionFactory.openSession();
//        BookDAO bookDAO = new BookDAO(sqlSession);
//        boolean result = bookDAO.delete(isbn) == 1;
//        if (result) {
//            sqlSession.commit();
//            sqlSession.close();
//        } else {
//            sqlSession.rollback();
//            sqlSession.close();
//        }
//        return result;
//    }
}
