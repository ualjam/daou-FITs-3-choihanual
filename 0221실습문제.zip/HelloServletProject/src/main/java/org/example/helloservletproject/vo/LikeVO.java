package org.example.helloservletproject.vo;

public class LikeVO {
    private int like_id;
    private int board_id;
    private String user_id;
    private String created_at;

    public LikeVO() {}

    public LikeVO(int like_id, int board_id, String user_id, String created_at) {
        this.like_id = like_id;
        this.board_id = board_id;
        this.user_id = user_id;
        this.created_at = created_at;
    }

    public int getLike_id() {
        return like_id;
    }

    public void setLike_id(int like_id) {
        this.like_id = like_id;
    }

    public int getBoard_id() {
        return board_id;
    }

    public void setBoard_id(int board_id) {
        this.board_id = board_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }
}
