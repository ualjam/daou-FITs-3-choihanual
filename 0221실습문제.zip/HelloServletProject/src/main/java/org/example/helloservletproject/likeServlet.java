package org.example.helloservletproject;

//import org.json.JSONObject;

import org.example.helloservletproject.service.BoardService;
import org.example.helloservletproject.service.BoardServiceOracleImpl;
import org.example.helloservletproject.service.LikeService;
import org.example.helloservletproject.service.LikeServiceOracleImpl;
import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.LikeVO;
import org.example.helloservletproject.vo.UserVO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(value = "/myServlet/like")
public class likeServlet extends HttpServlet {
    private LikeService likeService = new LikeServiceOracleImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");

        // 현재 로그인한 사용자 가져오기
        HttpSession session = req.getSession(false);
        UserVO user = (session != null) ? (UserVO) session.getAttribute("member") : null;

        if (user == null) {
            resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, "로그인이 필요합니다.");
            return;
        }

        // 요청에서 게시글 ID 가져오기
        int boardId = Integer.parseInt(req.getParameter("boardId"));
        String userId = user.getMember_id(); // 현재 로그인한 사용자 ID

        // 사용자가 이미 좋아요를 눌렀는지 확인
        LikeVO liked = likeService.isUserLiked(boardId, userId);

        int likeCount = 0;
        System.out.println(liked);
        PrintWriter out = resp.getWriter();
        if (liked != null) {
            // 이미 좋아요를 눌렀다면 → 좋아요 취소
            likeService.removeLike(boardId, userId);

            // 게시글 좋아요 수 빼기
            likeService.minusLikeCount(boardId);

            // 결론 좋아요 수 가져오기
            likeCount = likeService.getLikeCount(boardId);

            String jsonResponse = "{"
                    + "\"status\": \"success\", "
                    + "\"liked\": " + (false) + ", "
                    + "\"likeCount\": " + likeCount
                    + "}";

            out.write(jsonResponse);
        } else {
            // 좋아요 추가
            likeService.addLike(boardId, userId);

            // 게시글 좋아요 수 더하기
            likeService.addLikeCount(boardId);

            // 결론 좋아요 수 가져오기
            likeService.getLikeCount(boardId);
            likeCount = likeService.getLikeCount(boardId);

            String jsonResponse = "{"
                    + "\"status\": \"success\", "
                    + "\"liked\": " + (true) + ", "
                    + "\"likeCount\": " + likeCount
                    + "}";

            out.write(jsonResponse);
        }




        // 최신 좋아요 개수 가져오기
//        int likeCount = likeService.getLikeCount(boardId);
    }
}
