package org.example.helloservletproject;

import org.example.helloservletproject.service.BoardService;
import org.example.helloservletproject.service.BoardServiceOracleImpl;
import org.example.helloservletproject.service.CommentService;
import org.example.helloservletproject.service.CommentServiceOracleImpl;
import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.CommentVO;
import org.example.helloservletproject.vo.UserVO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(value = "/myServlet/board")
public class BoardServlet extends HttpServlet {

    private BoardService boardService = new BoardServiceOracleImpl();
    private CommentService commentService = new CommentServiceOracleImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idParam = req.getParameter("boardId");

        System.out.println(idParam);

        if (idParam != null) {
            // 특정 게시글 상세 조회
            int boardId = Integer.parseInt(idParam);

            boardService.updateViewCount(boardId);
            BoardVO board = boardService.getBoardDetail(boardId);
            List<CommentVO> commentVOList = commentService.getCommentList(boardId);


            if (board != null) {
                req.setAttribute("board", board);
                req.setAttribute("comments", commentVOList);
                RequestDispatcher rd = req.getRequestDispatcher("/viewPost.jsp");
                rd.forward(req, resp);
            } else {
                resp.sendRedirect(req.getContextPath() + "/boardNotFound.jsp");
            }
        } else {
            // 잘못된 요청 처리
            resp.sendRedirect(req.getContextPath() + "/boardError.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        HttpSession session = req.getSession();
        UserVO user = (UserVO) session.getAttribute("member"); // 현재 로그인한 사용자
        System.out.println("hihihihi");
        System.out.println(user);

//        if (userId == null) {
//            resp.sendRedirect(req.getContextPath() + "/login.html");
//            return;
//        }

        String action = req.getParameter("action"); // action 파라미터 가져오기

        if ("create".equals(action)) {
            // 📌 글 작성 처리
            String title = req.getParameter("title");
            String content = req.getParameter("content");

            BoardVO board = new BoardVO();
            board.setTitle(title);
            board.setContent(content);
            board.setUser_id(user.getMember_id());

            boardService.createBoard(board);
            System.out.println("please~~");
            // 글 작성 후, 해당 게시글 상세보기로 이동
            resp.sendRedirect(req.getContextPath() + "/myServlet/login");

        } else if ("delete".equals(action)) {
            // 📌 글 삭제 처리
            int boardId = Integer.parseInt(req.getParameter("id"));

            // 해당 게시글 가져오기
            BoardVO board = boardService.getBoardDetail(boardId);
            System.out.println(board);

            if (board != null) {
                System.out.println("bye");
                // 게시글 삭제 수행
                boardService.deleteBoard(boardId);
                // 삭제 후 게시판 목록으로 이동
                resp.sendRedirect(req.getContextPath() + "/myServlet/login");
            } else {
                System.out.println("hyhy");
                // 권한이 없는 경우 에러 페이지로 이동
                resp.sendRedirect(req.getContextPath() + "/unauthorized.jsp");
            }
        }
    }

}
