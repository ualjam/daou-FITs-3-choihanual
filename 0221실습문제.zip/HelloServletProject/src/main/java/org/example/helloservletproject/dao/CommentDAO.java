package org.example.helloservletproject.dao;

import org.apache.ibatis.session.SqlSession;
import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.CommentVO;

import java.util.Collection;
import java.util.List;

public class CommentDAO {
    private SqlSession sqlSession;

    public CommentDAO() {

    }

    public CommentDAO(SqlSession sqlSession) {this.sqlSession = sqlSession;}

    public Collection<? extends CommentVO> getCommentList(int boardId) {
        List<CommentVO> commentVOList = null;

        try {
            commentVOList = sqlSession.selectList("example.MyComment.getCommentList", boardId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }

        return commentVOList;
    }

    public int insert(CommentVO commentVO) {
        int result = 0;
        int resultId = 0;
        try {
            result = sqlSession.insert("example.MyComment.insert", commentVO);
            resultId = sqlSession.selectOne("example.MyComment.selectGeneratedId");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //            sqlSession.close();
        }
        return resultId;
    }

    public int delete(int id) {
        int result = 0;

        try {
            result = sqlSession.delete("example.MyComment.delete", id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }

        return result;
    }

    public int addCommentCount(int boardId) {
        int result = 0;

        try {
            result = sqlSession.update("example.MyComment.addCommentCount", boardId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }

        return result;
    }

    public int minusCommentCount(int boardId) {
        int result = 0;

        try {
            result = sqlSession.update("example.MyComment.minusCommentCount", boardId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }

        return result;
    }

    public int getCommentCount(int id) {

        int commentCount = 0;
        try {
            commentCount = sqlSession.selectOne("example.MyComment.getCommentCount", id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sqlSession.close();
        }


        return commentCount;
    }
}
