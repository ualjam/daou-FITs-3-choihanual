package org.example.helloservletproject.service;

import org.example.helloservletproject.vo.LikeVO;
import org.example.helloservletproject.vo.UserVO;

public interface LikeService {
    LikeVO isUserLiked(int boardId, String userId);
    boolean removeLike(int boardId, String userId);
    boolean addLike(int boardId, String userId);
    boolean minusLikeCount(int boardId);
    boolean addLikeCount(int boardId);
    int getLikeCount(int boardId);
}
