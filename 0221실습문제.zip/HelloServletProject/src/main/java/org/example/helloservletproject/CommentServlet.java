package org.example.helloservletproject;

import org.example.helloservletproject.service.CommentService;
import org.example.helloservletproject.service.CommentServiceOracleImpl;
import org.example.helloservletproject.vo.CommentVO;
import org.example.helloservletproject.vo.UserVO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(value = "/myServlet/comment")
public class CommentServlet extends HttpServlet {
    private CommentService commentService = new CommentServiceOracleImpl();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("application/json; charset=UTF-8");  // ✅ 응답 데이터 인코딩 설정
        resp.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        HttpSession session = req.getSession();
        UserVO user = (UserVO) session.getAttribute("member"); // 현재 로그인한 사용자

        // 로그인 확인
        if (user == null) {
            out.write("{\"status\": \"error\", \"message\": \"로그인이 필요합니다.\"}");
            return;
        }

        String action = req.getParameter("action"); // action 파라미터 가져오기

        if ("create".equals(action)) {
            // 댓글 작성 처리
            String content = req.getParameter("content");
            int boardId;

            try {
                boardId = Integer.parseInt(req.getParameter("boardId"));
            } catch (NumberFormatException e) {
                out.write("{\"status\": \"error\", \"message\": \"올바른 게시글 ID가 필요합니다.\"}");
                return;
            }

            if (content == null || content.trim().isEmpty()) {
                out.write("{\"status\": \"error\", \"message\": \"댓글 내용을 입력해주세요.\"}");
                return;
            }

            // 댓글 객체 생성 및 저장
            CommentVO comment = new CommentVO();
            comment.setUser_id(user.getMember_id());
            comment.setBoard_id(boardId);
            comment.setContent(content);

            int success = commentService.addComment(comment);
            commentService.addCommentCount(boardId);


            if (success != 0) {
                out.write("{\"status\": \"success\", " +
                        "\"user\": \"" + user.getMember_name() + "\", " +
                        "\"content\": \"" + content + "\", " +
                        "\"comment_id\": \"" + success + "\", " +
                        "\"comment_count\": \"" + commentService.getCommentCount(boardId) + "\"}");

            } else {
                out.write("{\"status\": \"error\", \"message\": \"댓글 작성에 실패했습니다.\"}");
            }

        } else if ("delete".equals(action)) {
            // 댓글 삭제 처리
            int commentId;
            int boardId;
            try {
                commentId = Integer.parseInt(req.getParameter("commentId"));
                boardId = Integer.parseInt(req.getParameter("boardId"));
            } catch (NumberFormatException e) {
                out.write("{\"status\": \"error\", \"message\": \"올바른 댓글 ID가 필요합니다.\"}");
                return;
            }

            System.out.println(commentId);

            boolean success = commentService.deleteComment(commentId);
            commentService.minusCommentCount(boardId);

            if (success) {
                out.write("{\"status\": \"success\", " +
                        "\"comment_count\": \"" + commentService.getCommentCount(boardId) + "\"}");
            } else {
                out.write("{\"status\": \"error\", \"message\": \"삭제 권한이 없거나 댓글이 존재하지 않습니다.\"}");
            }
        } else {
            // 잘못된 action 값 처리
            out.write("{\"status\": \"error\", \"message\": \"올바른 요청이 아닙니다.\"}");
        }
    }
}
