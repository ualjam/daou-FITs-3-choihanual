package org.example.helloservletproject.vo;

public class BoardVO {
    private int board_id;
    private String title;
    private String content;
    private String user_id;
    private String user_name;
    private String created_at;
    private String updated_at;
    private int like_count;
    private int view_count;
    private int comment_count;

    public BoardVO() {
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public BoardVO(int board_id, String title, String content, String user_id, String user_name, String created_at, String updated_at, int like_count, int view_count, int comment_count) {
        this.board_id = board_id;
        this.title = title;
        this.content = content;
        this.user_id = user_id;
        this.user_name = user_name;
        this.created_at = created_at;
        this.updated_at = updated_at;
        this.like_count = like_count;
        this.view_count = view_count;
        this.comment_count = comment_count;
    }

    public int getLike_count() {
        return like_count;
    }

    public void setLike_count(int like_count) {
        this.like_count = like_count;
    }

    public int getView_count() {
        return view_count;
    }

    public void setView_count(int view_count) {
        this.view_count = view_count;
    }

    public int getComment_count() {
        return comment_count;
    }

    public void setComment_count(int comment_count) {
        this.comment_count = comment_count;
    }

    public int getBoard_id() {
        return board_id;
    }

    public void setBoard_id(int board_id) {
        this.board_id = board_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }
}

