package org.example.helloservletproject;

import org.example.helloservletproject.service.BoardService;
import org.example.helloservletproject.service.BoardServiceOracleImpl;
import org.example.helloservletproject.service.LoginService;
import org.example.helloservletproject.service.LoginServiceOracleImpl;
import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.BookVO;
import org.example.helloservletproject.vo.UserVO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


@WebServlet(value = "/myServlet/editPost")
public class editPostServlet extends HttpServlet {

    public editPostServlet() {}

    @Override
    public void init() throws ServletException {
        super.init();
    }

    private BoardService boardService = new BoardServiceOracleImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idParam = req.getParameter("boardId");

        System.out.println(idParam);

        if (idParam != null) {
            // 특정 게시글 상세 조회
            int boardId = Integer.parseInt(idParam);
            BoardVO board = boardService.getBoardDetail(boardId);

            if (board != null) {
                req.setAttribute("board", board);
                RequestDispatcher rd = req.getRequestDispatcher("/editPost.jsp");
                rd.forward(req, resp);
            } else {
                resp.sendRedirect(req.getContextPath() + "/boardNotFound.jsp");
            }
        } else {
            // 잘못된 요청 처리
            resp.sendRedirect(req.getContextPath() + "/boardError.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 클라이언트의 요청이 GET 방식일 때 호출
        // 입력받고
        // Query String으로 전달되는 데이터는 무조건 문자열
        // 입려긍ㄹ 받을 때 만약 한글과 같은 유니코드가 포함되어 있다면
        String idParam = req.getParameter("boardId");
        String titleParam = req.getParameter("title");
        String contentParam = req.getParameter("content");
        int boardId = Integer.parseInt(idParam);
        BoardVO board = boardService.getBoardDetail(boardId);

        board.setTitle(titleParam);
        board.setContent(contentParam);
        boardService.updateBoard(board);

        resp.sendRedirect(req.getContextPath() + "/myServlet/login");
    }
}
