package org.example.helloservletproject.service;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.example.helloservletproject.dao.BoardDAO;
import org.example.helloservletproject.dao.BookDAO;
import org.example.helloservletproject.mybatis.MyBatisSessionFactory;
import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.BookVO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BoardServiceOracleImpl implements BoardService {
    @Override
    public List<BoardVO> getBoardList() {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BoardDAO boardDAO = new BoardDAO(sqlSession);
        List<BoardVO> BoardList = new ArrayList<>();
        BoardList.addAll(boardDAO.selectAllBoard());
        return BoardList;
    }

    @Override
    public List<BoardVO> searchBoards(String keyword) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BoardDAO boardDAO = new BoardDAO(sqlSession);
        List<BoardVO> BoardList = new ArrayList<>();

        BoardList.addAll(boardDAO.searchBoards(keyword));
        return BoardList;
    }

    @Override
    public boolean createBoard(BoardVO board) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BoardDAO boardDAO = new BoardDAO(sqlSession);
        boolean result = boardDAO.insert(board) == 1;

        if (result) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return result;
    }

    @Override
    public boolean updateBoard(BoardVO board) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BoardDAO boardDAO = new BoardDAO(sqlSession);
        boolean result = boardDAO.update(board) == 1;
        if (result) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return result;
    }

    @Override
    public boolean updateViewCount(int boardId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BoardDAO boardDAO = new BoardDAO(sqlSession);
        boolean result = boardDAO.updateViewCount(boardId) == 1;
        if (result) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return result;
    }

    @Override
    public boolean deleteBoard(int board_id) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        BoardDAO boardDAO = new BoardDAO(sqlSession);
        boolean result = boardDAO.delete(board_id) == 1;

        System.out.println(result);

        if (result) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return result;
    }

    @Override
    public BoardVO getBoardDetail(int board_id) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BoardDAO boardDAO = new BoardDAO(sqlSession);
        BoardVO result = boardDAO.getBoardDetail(board_id);
        return result;
    }
}
