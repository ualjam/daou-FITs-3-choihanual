package org.example.helloservletproject.service;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.example.helloservletproject.dao.BoardDAO;
import org.example.helloservletproject.dao.CommentDAO;
import org.example.helloservletproject.dao.LikeDAO;
import org.example.helloservletproject.mybatis.MyBatisSessionFactory;
import org.example.helloservletproject.vo.BoardVO;
import org.example.helloservletproject.vo.CommentVO;

import java.util.ArrayList;
import java.util.List;

public class CommentServiceOracleImpl implements CommentService {
    @Override
    public List<CommentVO> getCommentList(int boardId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        CommentDAO commentDAO = new CommentDAO(sqlSession);
        List<CommentVO> CommentList = new ArrayList<>();

        CommentList.addAll(commentDAO.getCommentList(boardId));
        return CommentList;
    }

    @Override
    public int addComment(CommentVO comment) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        CommentDAO commentDAO = new CommentDAO(sqlSession);

        int resultId = 0;
        resultId = commentDAO.insert(comment);

        if (resultId != 0) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return resultId;
    }

    @Override
    public boolean deleteComment(int commentId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        CommentDAO commentDAO = new CommentDAO(sqlSession);
        boolean result = commentDAO.delete(commentId) == 1;

        System.out.println(result);

        if (result) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return result;
    }

    @Override
    public boolean addCommentCount(int boardId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        CommentDAO commentDAO = new CommentDAO(sqlSession);

        boolean result = commentDAO.addCommentCount(boardId) == 1;
        if (result) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return result;
    }

    @Override
    public boolean minusCommentCount(int boardId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        CommentDAO commentDAO = new CommentDAO(sqlSession);
        boolean result = commentDAO.minusCommentCount(boardId) == 1;
        if (result) {
            sqlSession.commit();
            sqlSession.close();
        } else {
            sqlSession.rollback();
            sqlSession.close();
        }
        return result;
    }

    @Override
    public int getCommentCount(int boardId) {
        SqlSessionFactory sqlSessionFactory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();

        CommentDAO commentDAO = new CommentDAO(sqlSession);
        int result = commentDAO.getCommentCount(boardId);

        return result;
    }
}
